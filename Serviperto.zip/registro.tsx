// registro.tsx

import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

export default function Registro() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar style="light" />

      <View style={styles.card}>
        <Text style={styles.logo}>ServiPerto</Text>

        <Text style={styles.title}>Registro</Text>

         <TouchableOpacity
          onPress={() => navigation.navigate('app')}
        >
            <Text style={styles.subtitle}>
          Já possui uma conta?{' '}
          <Text style={styles.login}>Entrar</Text>
        </Text>
        </TouchableOpacity>
        

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Nome Completo</Text>

          <TextInput
            placeholder="Digite seu nome"
            style={styles.input}
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Email</Text>

          <TextInput
            placeholder="Digite seu email"
            style={styles.input}
            placeholderTextColor="#999"
            keyboardType="email-address"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Telefone</Text>

          <TextInput
            placeholder="(11) 99999-9999"
            style={styles.input}
            placeholderTextColor="#999"
            keyboardType="phone-pad"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Senha</Text>

          <TextInput
            placeholder="********"
            secureTextEntry
            style={styles.input}
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Confirmar Senha</Text>

          <TextInput
            placeholder="********"
            secureTextEntry
            style={styles.input}
            placeholderTextColor="#999"
          />
        </View>

        <TouchableOpacity style={styles.registerButton}>
          <Text style={styles.registerButtonText}>Cadastrar</Text>
        </TouchableOpacity>

        <Text style={styles.or}>Ou</Text>

        <TouchableOpacity style={styles.googleButton}>
          <Text style={styles.googleText}>
            Continuar com Google
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.roleButton}>
          <Text style={styles.roleText}>Cadastrar Autor</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.roleButton}>
          <Text style={styles.roleText}>Cadastrar Editor</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.roleButton}>
          <Text style={styles.roleText}>Cadastrar Leitor</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#1f1f1f',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  card: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 25,
    padding: 25,
    alignItems: 'center',
  },

  logo: {
    fontSize: 30,
    color: '#1e90ff',
    fontWeight: 'bold',
    marginBottom: 20,
  },

  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 10,
  },

  subtitle: {
    color: '#666',
    marginBottom: 30,
    fontSize: 15,
  },

  login: {
    color: '#2563eb',
    fontWeight: 'bold',
  },

  inputContainer: {
    width: '100%',
    marginBottom: 18,
  },

  label: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },

  input: {
    width: '100%',
    height: 55,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fafafa',
  },

  registerButton: {
    width: '100%',
    height: 55,
    backgroundColor: '#2563eb',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 25,
  },

  registerButtonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },

  or: {
    color: '#888',
    marginBottom: 20,
    fontSize: 16,
  },

  googleButton: {
    width: '100%',
    height: 55,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },

  googleText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111',
  },

  roleButton: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
  },

  roleText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111',
  },
});