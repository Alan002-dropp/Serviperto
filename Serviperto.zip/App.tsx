import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Registro from './registro';
import EsqueciSenha from './esqueciSenha';
import Financeiro from './financeiro';
import DashboardFinanceiro from './dashboardFinanceiro';
import Home from './home';
import PerfilUsuario from './perfilUsuario';
import ListaEstado from './listaEstado';
import Transacao from './transacao';




const Stack = createNativeStackNavigator();

function LoginScreen({ navigation }: any) {
  return (
    <View style={styles.container}>
      <StatusBar style="light" />

      <View style={styles.card}>
        <Text style={styles.logo}>
          ServiPerto
        </Text>

        <Text style={styles.title}>
          Login
        </Text>

        <Text style={styles.subtitle}>
          Não possui uma conta?
        </Text>

        <TouchableOpacity
          onPress={() => navigation.navigate('Registro')}
        >
          <Text style={styles.register}>
            Registre-se
          </Text>
        </TouchableOpacity>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>
            Email
          </Text>

          <TextInput
            placeholder="Loisbecket@gmail.com"
            style={styles.input}
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>
            Senha
          </Text>

          <TextInput
            placeholder="*******"
            secureTextEntry
            style={styles.input}
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.options}>
          <Text style={styles.remember}>
            ☐ Lembrar-me
          </Text>

          <TouchableOpacity
            onPress={() =>
              navigation.navigate('EsqueciSenha')
            }
          >
            <Text style={styles.forgot}>
              Esqueceu a Senha?
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.loginButton}
          onPress={() =>
            navigation.navigate('Home')
          }
        >
          <Text style={styles.loginText}>
            Entrar
          </Text>
        </TouchableOpacity>

        <Text style={styles.or}>
          Ou
        </Text>

        <TouchableOpacity
          style={styles.googleButton}
        >
          <Text style={styles.googleText}>
            Continuar com Google
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.roleButton}
        >
          <Text style={styles.roleText}>
            Login Autor
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.roleButton}
        >
          <Text style={styles.roleText}>
            Login Editor
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.roleButton}
        >
          <Text style={styles.roleText}>
            Login Leitor
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen
          name="Login"
          component={LoginScreen}
        />

        <Stack.Screen
          name="Home"
          component={Home}
        />

        <Stack.Screen
          name="Registro"
          component={Registro}
        />

        <Stack.Screen
          name="EsqueciSenha"
          component={EsqueciSenha}
        />

        <Stack.Screen
          name="Financeiro"
          component={Financeiro}
        />

        <Stack.Screen
          name="DashboardFinanceiro"
          component={DashboardFinanceiro}
        />

        <Stack.Screen
        name="PerfilUsuario"
        component={PerfilUsuario}
        />

         <Stack.Screen
        name="ListaEstado"
        component={ListaEstado}
        />
        <Stack.Screen
        name="Transacao"
         component={Transacao}
         options={{ headerShown: false }}
        />


      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1f1f1f',
    justifyContent: 'center',
    alignItems: 'center',
  },

  card: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 25,
    padding: 25,
    alignItems: 'center',
  },

  logo: {
    fontSize: 28,
    color: '#1e90ff',
    fontWeight: 'bold',
    marginBottom: 20,
  },

  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 10,
  },

  subtitle: {
    color: '#666',
    fontSize: 15,
  },

  register: {
    color: '#3b82f6',
    fontWeight: 'bold',
    marginBottom: 30,
    fontSize: 16,
  },

  inputContainer: {
    width: '100%',
    marginBottom: 18,
  },

  label: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },

  input: {
    width: '100%',
    height: 55,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fafafa',
  },

  options: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 25,
  },

  remember: {
    color: '#666',
  },

  forgot: {
    color: '#3b82f6',
    fontWeight: 'bold',
  },

  loginButton: {
    width: '100%',
    height: 55,
    backgroundColor: '#2563eb',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 25,
  },

  loginText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },

  or: {
    color: '#888',
    marginBottom: 20,
    fontSize: 16,
  },

  googleButton: {
    width: '100%',
    height: 55,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },

  googleText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111',
  },

  roleButton: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
  },

  roleText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111',
  },
});