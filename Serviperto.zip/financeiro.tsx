// financeiro.tsx

import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
 Image,
} from 'react-native';

export default function Financeiro({ navigation }: any) {
  return (
    <ScrollView style={financeiro.container}>
      <StatusBar style="dark" />

      {/* HEADER */}
      {/* HEADER */}
<View style={financeiro.header}>
  <View style={financeiro.profileArea}>

    <TouchableOpacity
      onPress={() => navigation.goBack()}
    >
      <Text style={financeiro.backButton}>
        ←
      </Text>
    </TouchableOpacity>

    <Image
      source={require('./fotoUsuario.png')}
      style={financeiro.avatar}
    />

    <View>
      <Text style={financeiro.greeting}>
        Olá,
      </Text>

      <Text style={financeiro.userName}>
        Ana Clara
      </Text>
    </View>

  </View>

  <TouchableOpacity>
    <Text style={financeiro.notification}>
      🔔
    </Text>
  </TouchableOpacity>
</View>

      {/* CARD SALDO */}
      <View style={financeiro.balanceCard}>
        <Text style={financeiro.balanceLabel}>
          Saldo total
        </Text>

        <Text style={financeiro.balanceValue}>
          R$ 1.250,00
        </Text>

        <View style={financeiro.badge}>
          <Text style={financeiro.badgeText}>
            ↗ +12% este mês
          </Text>
        </View>

        <View style={financeiro.actionsContainer}>
          <TouchableOpacity style={financeiro.actionButton}>
            <Text style={financeiro.actionText}>
              + Adicionar saldo
            </Text>
          </TouchableOpacity>
<TouchableOpacity
  style={financeiro.actionButton}
  onPress={() => navigation.navigate('Transacao')}
>
  <Text style={financeiro.actionText}>
    ↗ Transferir
  </Text>
</TouchableOpacity>
          
        </View>
      </View>

      {/* MOVIMENTAÇÕES */}
      <View style={financeiro.section}>
        <View style={financeiro.sectionHeader}>
          <Text style={financeiro.sectionTitle}>
            Últimas movimentações
          </Text>

          <TouchableOpacity>
            <Text style={financeiro.link}>
              Ver todas
            </Text>
          </TouchableOpacity>
        </View>

        <View style={financeiro.transactionItem}>
          <View>
            <Text style={financeiro.transactionTitle}>
              Publicação impulsionada
            </Text>

            <Text style={financeiro.transactionDate}>
              Hoje, 09:30
            </Text>
          </View>

          <Text style={financeiro.negativeValue}>
            -R$ 25,00
          </Text>
        </View>

        <View style={financeiro.divider} />

        <View style={financeiro.transactionItem}>
          <View>
            <Text style={financeiro.transactionTitle}>
              Serviço contratado
            </Text>

            <Text style={financeiro.transactionDate}>
              Ontem, 14:20
            </Text>
          </View>

          <Text style={financeiro.negativeValue}>
            -R$ 130,00
          </Text>
        </View>

        <View style={financeiro.divider} />

        <View style={financeiro.transactionItem}>
          <View>
            <Text style={financeiro.transactionTitle}>
              Comissão recebida
            </Text>

            <Text style={financeiro.transactionDate}>
              17 Mai, 10:15
            </Text>
          </View>

          <Text style={financeiro.positiveValue}>
            +R$ 80,00
          </Text>
        </View>
      </View>

      {/* SERVIÇOS */}
      <View style={financeiro.section}>
        <View style={financeiro.sectionHeader}>
          <Text style={financeiro.sectionTitle}>
            Serviços mais vendidos
          </Text>

          <TouchableOpacity>
            <Text style={financeiro.link}>
              Ver relatório
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
        >
          <View style={financeiro.serviceCard}>
            <Text style={financeiro.serviceEmoji}>
              👷
            </Text>

            <Text style={financeiro.serviceTitle}>
              Eletricista
            </Text>

            <Text style={financeiro.serviceOrders}>
              28 pedidos
            </Text>

            <Text style={financeiro.servicePrice}>
              R$ 2.240,00
            </Text>
          </View>

          <View style={financeiro.serviceCard}>
            <Text style={financeiro.serviceEmoji}>
              🎨
            </Text>

            <Text style={financeiro.serviceTitle}>
              Pintor
            </Text>

            <Text style={financeiro.serviceOrders}>
              18 pedidos
            </Text>

            <Text style={financeiro.servicePrice}>
              R$ 1.620,00
            </Text>
          </View>

          <View style={financeiro.serviceCard}>
            <Text style={financeiro.serviceEmoji}>
              🔧
            </Text>

            <Text style={financeiro.serviceTitle}>
              Encanador
            </Text>

            <Text style={financeiro.serviceOrders}>
              15 pedidos
            </Text>

            <Text style={financeiro.servicePrice}>
              R$ 1.150,00
            </Text>
          </View>
        </ScrollView>
      </View>
    </ScrollView>
  );
}

const financeiro = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4',
    paddingTop: 55,
    paddingHorizontal: 20,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },

  profileArea: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },

  greeting: {
    fontSize: 18,
    color: '#777',
  },

  userName: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#111',
  },

  notification: {
    fontSize: 30,
  },

  balanceCard: {
    backgroundColor: '#2563eb',
    borderRadius: 30,
    padding: 25,
    marginBottom: 25,
  },

  balanceLabel: {
    color: '#fff',
    fontSize: 20,
    marginBottom: 10,
  },

  balanceValue: {
    color: '#fff',
    fontSize: 45,
    fontWeight: 'bold',
    marginBottom: 18,
  },

  badge: {
    backgroundColor: '#4f83ff',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginBottom: 25,
  },

  badgeText: {
    color: '#fff',
    fontWeight: '600',
  },

  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  actionButton: {
    width: '48%',
    backgroundColor: '#4f83ff',
    padding: 18,
    borderRadius: 18,
    alignItems: 'center',
  },

  actionText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },

  section: {
    backgroundColor: '#fff',
    borderRadius: 25,
    padding: 20,
    marginBottom: 20,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111',
  },

  link: {
    color: '#2563eb',
    fontWeight: '600',
    fontSize: 16,
  },

  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },

  divider: {
    height: 1,
    backgroundColor: '#eee',
    marginBottom: 15,
  },

  transactionTitle: {
    fontSize: 20,
    color: '#111',
  },

  transactionDate: {
    color: '#777',
    marginTop: 4,
  },

  negativeValue: {
    color: '#ff3b30',
    fontWeight: 'bold',
    fontSize: 22,
  },

  positiveValue: {
    color: '#16a34a',
    fontWeight: 'bold',
    fontSize: 22,
  },

  serviceCard: {
    width: 170,
    backgroundColor: '#f8f8f8',
    borderRadius: 20,
    padding: 15,
    marginRight: 15,
  },

  serviceEmoji: {
    fontSize: 42,
    marginBottom: 10,
  },

  serviceTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
  },

  serviceOrders: {
    color: '#777',
    marginBottom: 8,
  },

  servicePrice: {
    color: '#2563eb',
    fontWeight: 'bold',
    fontSize: 22,
  },

  backButton: {
  fontSize: 34,
  color: '#2563eb',
  fontWeight: 'bold',
  marginRight: 12,
},

});