import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';

export default function PerfilUsuario({ navigation }: any) {
  return (
    <ScrollView style={styles.container}>
      <StatusBar style="dark" />

      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.back}>←</Text>
        <Text style={styles.title}>Perfil do Usuário</Text>
        <Text style={styles.menu}>⋯</Text>
      </View>

      {/* PERFIL */}
      <View style={styles.profileCard}>
        <Image
        source={require('./fotoUsuario.png')}
        style={styles.avatar}
      />

        <Text style={styles.name}>
          Ana Clara
        </Text>

        <Text style={styles.info}>
          📧 anaclara@email.com
        </Text>

        <Text style={styles.info}>
          📍 São Paulo, SP
        </Text>

        <TouchableOpacity
          style={styles.messageButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.messageText}>
            Voltar
          </Text>
        </TouchableOpacity>

        </View>

      {/* ESTATÍSTICAS */}
      <View style={styles.statsContainer}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>12</Text>
          <Text>Publicações</Text>
        </View>

        <View style={styles.statBox}>
          <Text style={styles.statNumber}>8</Text>
          <Text>Salvos</Text>
        </View>

        <View style={styles.statBox}>
          <Text style={styles.statNumber}>5</Text>
          <Text>Serviços</Text>
        </View>
      </View>

      {/* SOBRE */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          Sobre Ana
        </Text>

        <Text style={styles.description}>
          Apaixonada por organização e soluções
          práticas para o dia a dia. Aqui para
          encontrar os melhores profissionais e
          serviços.
        </Text>
      </View>

      {/* ATIVIDADES */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          Atividade recente
        </Text>

        <Text style={styles.activity}>
          ✅ Avaliou o serviço de Pintor
        </Text>

        <Text style={styles.activity}>
          📄 Publicou uma nova solicitação
        </Text>

        <Text style={styles.activity}>
          🔖 Salvou o serviço de Eletricista
        </Text>
      </View>

      {/* INFORMAÇÕES */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          Informações do usuário
        </Text>

        <Text style={styles.infoItem}>
          👤 Ana Clara Silva
        </Text>

        <Text style={styles.infoItem}>
          📞 (11) 98765-4321
        </Text>

        <Text style={styles.infoItem}>
          📧 anaclara@email.com
        </Text>

        <Text style={styles.infoItem}>
          🔒 Alterar senha
        </Text>
      </View>

      {/* SAIR */}
      <TouchableOpacity style={styles.logoutButton}>
        <Text style={styles.logoutText}>
          Sair da conta
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f8',
    paddingTop: 50,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },

  back: {
    fontSize: 28,
  },

  menu: {
    fontSize: 28,
  },

  title: {
    fontSize: 22,
    fontWeight: 'bold',
  },

  profileCard: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    borderRadius: 25,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },

  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
  },

  name: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  info: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },

  messageButton: {
    backgroundColor: '#2563eb',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 15,
    marginTop: 15,
  },

  messageText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 15,
    marginBottom: 20,
  },

  statBox: {
    width: '31%',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 15,
    alignItems: 'center',
  },

  statNumber: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#2563eb',
  },

  card: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    borderRadius: 25,
    padding: 20,
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 15,
  },

  description: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
  },

  activity: {
    fontSize: 16,
    marginBottom: 15,
  },

  infoItem: {
    fontSize: 16,
    marginBottom: 15,
  },

  logoutButton: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 30,
    borderRadius: 20,
    padding: 18,
    alignItems: 'center',
  },

  logoutText: {
    color: '#ef4444',
    fontSize: 18,
    fontWeight: 'bold',
  },
});