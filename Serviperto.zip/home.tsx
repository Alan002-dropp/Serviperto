// home.tsx

import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
} from 'react-native';


export default function home({ navigation }: any) {
  return (
    <ScrollView style={styles.container}>
      <StatusBar style="dark" />

      {/* CABEÇALHO */}
      <View style={styles.header}>
        <Text style={styles.menu}>☰</Text>

        <Text style={styles.headerTitle}>
          Serviços
        </Text>
      </View>

      {/* CONTEÚDO */}
      <View style={styles.card}>

        <View style={styles.topArea}>
          <View>
            <Text style={styles.smallText}>
              Explorar
            </Text>

            <Text style={styles.bigTitle}>
              serviços
            </Text>
          </View>

          <Text style={styles.location}>
            📍 Taguatinga, DF
          </Text>
        </View>

        {/* PESQUISA */}
        <TextInput
          style={styles.search}
          placeholder="Buscar serviços..."
        />

        {/* CATEGORIAS */}
        <View style={styles.categories}>
          <TouchableOpacity style={styles.activeCategory}>
            <Text style={styles.activeCategoryText}>
              Localização
            </Text>
          </TouchableOpacity>

          <Text style={styles.category}>
            Comentários
          </Text>

          <Text style={styles.category}>
            Notícias
          </Text>

          <Text style={styles.category}>
            Outros
          </Text>
        </View>

        {/* POPULARES */}
<View style={styles.sectionHeader}>
  <Text style={styles.sectionTitle}>
    Popular
  </Text>

  <Text style={styles.seeAll}>
    Ver tudo
  </Text>
</View>

<View style={styles.row}>
  <View style={styles.serviceCard}>
    <Image
      source={require('./img_pintor.png')}
      style={styles.image}
    />

    <Text style={styles.serviceName}>
      Pintor, Guilherme
    </Text>

    <Text style={styles.rating}>
      ⭐ 4.5
    </Text>
  </View>

  <View style={styles.serviceCard}>
    <Image
      source={require('./img_eletricista.png')}
      style={styles.image}
    />

    <Text style={styles.serviceName}>
      Eletricista, João
    </Text>

    <Text style={styles.rating}>
      ⭐ 4.5
    </Text>
  </View>
</View>

{/* RECOMENDADOS */}
<Text style={styles.sectionTitle}>
  Serviços Recomendados
</Text>

<View style={styles.row}>
  <View style={styles.serviceCardLarge}>
    <Image
      source={require('./img_veterinria.png')}
      style={styles.largeImage}
    />

    <Text style={styles.serviceName}>
      Veterinária, Julia
    </Text>

    <Text style={styles.rating}>
      ⭐ 4.9
    </Text>
  </View>

  <View style={styles.serviceCardLarge}>
    <Image
      source={require('./img_cabeleireira.png')}
      style={styles.largeImage}
    />

    <Text style={styles.serviceName}>
      Cabeleireira, Ana
    </Text>

    <Text style={styles.rating}>
      ⭐ 4.4
    </Text>
  </View>
</View>
        {/* MENU INFERIOR */}
        <View style={styles.bottomNav}>
          <TouchableOpacity>
            <Text style={styles.navIcon}>
              🏠
            </Text>
          </TouchableOpacity>

           <TouchableOpacity
            onPress={() =>
                navigation.navigate('ListaEstado')
            }
            >
            <Text style={styles.navIcon}>
                ☺☺
            </Text>
            </TouchableOpacity>


          <TouchableOpacity
            onPress={() =>
                navigation.navigate('PerfilUsuario')
            }
            >
            <Text style={styles.navIcon}>
                👤
            </Text>
            </TouchableOpacity>


          <TouchableOpacity
            onPress={() =>
              navigation.navigate('Financeiro')
            }
          >
            <Text style={styles.navIcon}>
              💰
            </Text>
          </TouchableOpacity>
        </View>

      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1f1f1f',
  },

  header: {
    height: 90,
    backgroundColor: '#222',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },

  menu: {
    color: '#fff',
    fontSize: 28,
  },

  headerTitle: {
    color: '#fff',
    fontSize: 24,
  },

  card: {
    backgroundColor: '#fff',
    margin: 15,
    borderRadius: 35,
    padding: 20,
  },

  topArea: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  smallText: {
    color: '#666',
    fontSize: 18,
  },

  bigTitle: {
    fontSize: 48,
    fontWeight: 'bold',
  },

  location: {
    fontSize: 16,
  },

  search: {
    backgroundColor: '#f3f6fb',
    borderRadius: 20,
    padding: 15,
    marginTop: 25,
  },

  categories: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 25,
    marginBottom: 25,
  },

  activeCategory: {
    backgroundColor: '#edf4ff',
    padding: 12,
    borderRadius: 15,
  },

  activeCategoryText: {
    color: '#2563eb',
    fontWeight: 'bold',
  },

  category: {
    color: '#888',
    paddingTop: 12,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },

  sectionTitle: {
    fontSize: 28,
    fontWeight: 'bold',
  },

  seeAll: {
    color: '#2563eb',
  },

  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 25,
  },

  serviceCard: {
    width: '48%',
  },

  image: {
    width: '100%',
    height: 180,
    borderRadius: 20,
  },

  serviceCardLarge: {
    width: '48%',
  },

  largeImage: {
    width: '100%',
    height: 220,
    borderRadius: 20,
  },

  serviceName: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },

  rating: {
    marginTop: 5,
    color: '#555',
  },

  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
    marginTop: 10,
    borderTopWidth: 1,
    borderColor: '#eee',
  },

  navIcon: {
    fontSize: 26,
  },
});