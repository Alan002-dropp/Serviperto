import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';

export default function dashboardFinanceiro() {
  return (
    <ScrollView style={dashboard.container}>
      <StatusBar style="dark" />

      {/* HEADER */}
      <View style={dashboard.header}>
        <View style={dashboard.profileArea}>
          <Image
            source={{
              uri: 'https://i.pravatar.cc/150?img=5',
            }}
            style={dashboard.avatar}
          />

          <View>
            <Text style={dashboard.greeting}>Olá,</Text>
            <Text style={dashboard.userName}>
              Ana Clara
            </Text>
          </View>
        </View>

        <TouchableOpacity>
          <Text style={dashboard.notification}>
            🔔
          </Text>
        </TouchableOpacity>
      </View>

      {/* SALDO */}
      <View style={dashboard.balanceCard}>
        <Text style={dashboard.balanceLabel}>
          Saldo disponível
        </Text>

        <Text style={dashboard.balanceValue}>
          R$ 1.250,00
        </Text>

        <Text style={dashboard.badge}>
          ↗ +12% este mês
        </Text>

        {/* Gráfico */}
        <View style={dashboard.graph}>
          <Text style={dashboard.graphText}>
            Área do gráfico financeiro
          </Text>
        </View>

        <View style={dashboard.actionsRow}>
          <TouchableOpacity style={dashboard.action}>
            <Text>➕ Adicionar saldo</Text>
          </TouchableOpacity>

          <TouchableOpacity style={dashboard.action}>
            <Text>↗ Transferir</Text>
          </TouchableOpacity>

          <TouchableOpacity style={dashboard.action}>
            <Text>⬆ Sacar</Text>
          </TouchableOpacity>

          <TouchableOpacity style={dashboard.action}>
            <Text>📄 Extrato</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* MOVIMENTAÇÕES */}
      <View style={dashboard.card}>
        <Text style={dashboard.sectionTitle}>
          Últimas movimentações
        </Text>

        <Text style={dashboard.item}>
          Publicação impulsionada - R$ 25,00
        </Text>

        <Text style={dashboard.item}>
          Serviço contratado - R$ 130,00
        </Text>

        <Text style={dashboard.item}>
          Comissão recebida + R$ 80,00
        </Text>

        <Text style={dashboard.item}>
          Assinatura Premium - R$ 19,90
        </Text>
      </View>

      {/* RESUMO */}
      <View style={dashboard.card}>
        <Text style={dashboard.sectionTitle}>
          Resumo do mês
        </Text>

        <View style={dashboard.resumeRow}>
          <View style={dashboard.resumeBox}>
            <Text>Receitas</Text>
            <Text>R$ 2.450,00</Text>
          </View>

          <View style={dashboard.resumeBox}>
            <Text>Despesas</Text>
            <Text>R$ 980,00</Text>
          </View>

          <View style={dashboard.resumeBox}>
            <Text>Saldo</Text>
            <Text>R$ 1.470,00</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const dashboard = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 50,
    paddingHorizontal: 15,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },

  profileArea: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  avatar: {
    width: 55,
    height: 55,
    borderRadius: 30,
    marginRight: 12,
  },

  greeting: {
    fontSize: 18,
    color: '#777',
  },

  userName: {
    fontSize: 32,
    fontWeight: 'bold',
  },

  notification: {
    fontSize: 28,
  },

  balanceCard: {
    backgroundColor: '#0D5BFF',
    borderRadius: 25,
    padding: 20,
    marginBottom: 20,
  },

  balanceLabel: {
    color: '#fff',
    fontSize: 18,
  },

  balanceValue: {
    color: '#fff',
    fontSize: 42,
    fontWeight: 'bold',
    marginVertical: 10,
  },

  badge: {
    color: '#fff',
    marginBottom: 15,
  },

  graph: {
    height: 180,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },

  graphText: {
    color: '#fff',
  },

  actionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  action: {
    backgroundColor: '#fff',
    width: '48%',
    padding: 12,
    borderRadius: 12,
    marginTop: 10,
    alignItems: 'center',
  },

  card: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 18,
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },

  item: {
    fontSize: 16,
    marginBottom: 12,
  },

  resumeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  resumeBox: {
    width: '31%',
    backgroundColor: '#f8f8f8',
    padding: 12,
    borderRadius: 15,
  },
});