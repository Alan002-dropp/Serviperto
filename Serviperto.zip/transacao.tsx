
import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from 'react-native';

import {
  Ionicons,
  Feather,
  MaterialCommunityIcons,
} from '@expo/vector-icons';

export default function Transacao({ navigation }: any) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <StatusBar style="dark" />

      {/* Cabeçalho */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={28} color="#000" />
        </TouchableOpacity>

        <Text style={styles.title}>Transferência</Text>

        <Text style={styles.subtitle}>
          Envie pagamentos de forma rápida e segura
        </Text>
      </View>

      {/* Card */}
      <View style={styles.card}>

        <Text style={styles.label}>Valor</Text>

        <View style={styles.input}>
          <View style={styles.iconBox}>
            <Feather name="credit-card" size={24} color="#2563EB" />
          </View>

          <TextInput
            value="R$ 250,00"
            style={styles.textInput}
          />
        </View>

        <Text style={styles.label}>Destinatário</Text>

        <View style={styles.input}>
          <View style={styles.iconBox}>
            <Ionicons name="person-outline" size={24} color="#2563EB" />
          </View>

          <TextInput
            value="Ana Zezilda"
            style={styles.textInput}
          />
        </View>

        <Text style={styles.label}>Chave PIX</Text>

        <View style={styles.input}>
          <View style={styles.iconBox}>
            <MaterialCommunityIcons
              name="qrcode"
              size={24}
              color="#2563EB"
            />
          </View>

          <TextInput
            value="ana@email.com"
            style={styles.textInput}
          />
        </View>

        <Text style={styles.label}>Descrição (opcional)</Text>

        <View style={styles.textArea}>
          <View style={styles.iconBox}>
            <Ionicons
              name="chatbubble-outline"
              size={24}
              color="#2563EB"
            />
          </View>

          <TextInput
            value="Pagamento do serviço"
            multiline
            style={styles.textAreaInput}
          />
        </View>

        <TouchableOpacity style={styles.button}>
          <Ionicons name="paper-plane-outline" size={24} color="#fff" />

          <Text style={styles.buttonText}>
            Confirmar Transferência
          </Text>
        </TouchableOpacity>
      </View>

      {/* Menu Inferior */}
      <View style={styles.bottomBar}>

        <TouchableOpacity>
          <Ionicons name="home" size={30} color="#2563EB" />
        </TouchableOpacity>

        <TouchableOpacity>
          <MaterialCommunityIcons
            name="ticket-percent-outline"
            size={30}
            color="#888"
          />
        </TouchableOpacity>

        <TouchableOpacity>
          <Ionicons
            name="heart-outline"
            size={30}
            color="#888"
          />
        </TouchableOpacity>

        <TouchableOpacity>
          <Ionicons
            name="person-outline"
            size={30}
            color="#888"
          />
        </TouchableOpacity>

      </View>

    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F6FA',
  },

  header: {
    paddingTop: 60,
    alignItems: 'center',
    marginBottom: 20,
  },

  backButton: {
    position: 'absolute',
    left: 25,
    top: 50,
    width: 50,
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
  },

  title: {
    fontSize: 34,
    fontWeight: 'bold',
    color: '#111827',
  },

  subtitle: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },

  card: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    borderRadius: 30,
    padding: 22,
    elevation: 3,
    marginBottom: 30,
  },

  label: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
    marginTop: 10,
  },

  input: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 18,
    height: 74,
    paddingHorizontal: 14,
    marginBottom: 22,
  },

  iconBox: {
    width: 52,
    height: 52,
    borderRadius: 14,
    backgroundColor: '#F8FAFC',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },

  textInput: {
    flex: 1,
    fontSize: 18,
    color: '#111827',
  },

  textArea: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 18,
    padding: 14,
    height: 150,
    marginBottom: 30,
  },
  textAreaInput: {
    flex: 1,
    fontSize: 18,
    color: '#111827',
    textAlignVertical: 'top',
    paddingTop: 8,
    marginLeft: 15,
  },

  button: {
    height: 65,
    backgroundColor: '#2563EB',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    elevation: 4,
  },

  buttonText: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 12,
  },

  bottomBar: {
    marginHorizontal: 20,
    marginBottom: 30,
    backgroundColor: '#fff',
    height: 90,
    borderRadius: 28,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    elevation: 5,
  },
});