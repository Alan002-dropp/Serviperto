// esqueciSenha.tsx

import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';

export default function EsqueciSenha() {
  return (
    <View style={styles.container}>
      <StatusBar style="light" />

      <View style={styles.card}>
        <Text style={styles.logo}>ServiPerto</Text>

        <Text style={styles.title}>Recuperar Senha</Text>

        <Text style={styles.subtitle}>
          Digite seu email para receber um link de recuperação de senha.
        </Text>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Email</Text>

          <TextInput
            placeholder="Digite seu email"
            style={styles.input}
            placeholderTextColor="#999"
            keyboardType="email-address"
          />
        </View>

        <TouchableOpacity style={styles.resetButton}>
          <Text style={styles.resetButtonText}>
            Enviar Link
          </Text>
        </TouchableOpacity>
        
         <TouchableOpacity
        onPress={() =>  navigation.navigate('EsqueciSenha') }
        >
          <Text style={styles.backLogin}>
            Voltar para Login
          </Text>
         </TouchableOpacity>
         </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1f1f1f',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  card: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 25,
    padding: 25,
    alignItems: 'center',
  },

  logo: {
    fontSize: 30,
    color: '#1e90ff',
    fontWeight: 'bold',
    marginBottom: 20,
  },

  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 15,
    textAlign: 'center',
  },

  subtitle: {
    color: '#666',
    marginBottom: 30,
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
  },

  inputContainer: {
    width: '100%',
    marginBottom: 25,
  },

  label: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },

  input: {
    width: '100%',
    height: 55,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fafafa',
  },

  resetButton: {
    width: '100%',
    height: 55,
    backgroundColor: '#2563eb',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 25,
  },

  resetButtonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },

  backLogin: {
    color: '#2563eb',
    fontSize: 16,
    fontWeight: 'bold',
  },
});