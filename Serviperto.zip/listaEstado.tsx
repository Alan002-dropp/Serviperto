import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
} from 'react-native';

export default function ListaEstado({ navigation }: any) {
  const [ufs, setUfs] = useState<any[]>([]);

  useEffect(() => {
    carregarUFs();
  }, []);

  const carregarUFs = async () => {
    try {
      const response = await axios.get('http://localhost:3000/uf');
      setUfs(response.data);
    } catch (error) {
      console.log('Erro ao carregar UFs:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <StatusBar style="dark" />

      <Text style={styles.sectionTitle}>Lista de Estados</Text>

      {ufs.map((uf) => (
        <View key={uf.id} style={styles.card}>
          <Text style={styles.name}>{uf.nome}</Text>
          <Text style={styles.info}>ID: {uf.id}</Text>
          <Text style={styles.info}>Sigla: {uf.sigla}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f8',
    paddingTop: 50,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },

  back: {
    fontSize: 28,
  },

  menu: {
    fontSize: 28,
  },

  title: {
    fontSize: 22,
    fontWeight: 'bold',
  },

  profileCard: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    borderRadius: 25,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },

  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
  },

  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  info: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },

  messageButton: {
    backgroundColor: '#2563eb',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 15,
    marginTop: 15,
  },

  messageText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 15,
    marginBottom: 20,
  },

  statBox: {
    width: '31%',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 15,
    alignItems: 'center',
  },

  statNumber: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#2563eb',
  },

  card: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    borderRadius: 25,
    padding: 20,
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginHorizontal: 15,
    marginBottom: 20,
  },

  description: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
  },

  activity: {
    fontSize: 16,
    marginBottom: 15,
  },

  infoItem: {
    fontSize: 16,
    marginBottom: 15,
  },

  logoutButton: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 30,
    borderRadius: 20,
    padding: 18,
    alignItems: 'center',
  },

  logoutText: {
    color: '#ef4444',
    fontSize: 18,
    fontWeight: 'bold',
  },
});