CREATE TABLE `financeiro` (
	`id` text PRIMARY KEY NOT NULL,
	`descricao` text NOT NULL,
	`valor` text NOT NULL,
	`tipo` text NOT NULL,
	`data` text NOT NULL,
	`tipo_pagamento` text NOT NULL,
	`status` text NOT NULL,
	`observacao` text NOT NULL
);
