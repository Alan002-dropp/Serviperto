CREATE TABLE `servico` (
	`id` text PRIMARY KEY NOT NULL,
	`nome` text NOT NULL,
	`descricao` text NOT NULL,
	`preco` text NOT NULL
);
