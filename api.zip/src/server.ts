import express from "express";
import { db } from "./db";
import { uf, cidade, regiao, usuario, servico, financeiro} from "./schema";
import { eq } from "drizzle-orm";
import cors from "cors";

const app = express();

app.use(cors());
app.use(express.json());

/* =======================
   HOME
======================= */

app.get("/", (req, res) => {
  res.send("API funcionando 🚀");
});

/* =======================
   UF CRUD
======================= */

// CREATE
app.post("/uf", async (req, res) => {
  const { id, nome, sigla } = req.body;

  await db.insert(uf).values({
    id,
    nome,
    sigla,
  });

  res.json({
    message: "UF criada",
  });
});

// READ
app.get("/uf", async (req, res) => {
  const data = await db.select().from(uf);

  res.json(data);
});

// UPDATE
app.put("/uf/:id", async (req, res) => {
  const { id } = req.params;

  const { nome, sigla } = req.body;

  await db
    .update(uf)
    .set({
      nome,
      sigla,
    })
    .where(eq(uf.id, id));

  res.json({
    message: "UF atualizada",
  });
});

// DELETE
app.delete("/uf/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(uf).where(eq(uf.id, id));

  res.json({
    message: "UF deletada",
  });
});

/* =======================
   CIDADE CRUD
======================= */

// CREATE
app.post("/cidade", async (req, res) => {
  const { id, nome, uf_id } = req.body;

  await db.insert(cidade).values({
    id,
    nome,
    uf_id,
  });

  res.json({
    message: "Cidade criada",
  });
});

// READ
app.get("/cidade", async (req, res) => {
  const data = await db.select().from(cidade);

  res.json(data);
});

// UPDATE
app.put("/cidade/:id", async (req, res) => {
  const { id } = req.params;

  const { nome, uf_id } = req.body;

  await db
    .update(cidade)
    .set({
      nome,
      uf_id,
    })
    .where(eq(cidade.id, id));

  res.json({
    message: "Cidade atualizada",
  });
});

// DELETE
app.delete("/cidade/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(cidade).where(eq(cidade.id, id));

  res.json({
    message: "Cidade deletada",
  });
});

/* =======================
   REGIAO CRUD
======================= */

// CREATE
app.post("/regiao", async (req, res) => {
  const { id, nome, cidade_id } = req.body;

  await db.insert(regiao).values({
    id,
    nome,
    cidade_id,
  });

  res.json({
    message: "Região criada",
  });
});

// READ
app.get("/regiao", async (req, res) => {
  const data = await db.select().from(regiao);

  res.json(data);
});

// UPDATE
app.put("/regiao/:id", async (req, res) => {
  const { id } = req.params;

  const { nome, cidade_id } = req.body;

  await db
    .update(regiao)
    .set({
      nome,
      cidade_id,
    })
    .where(eq(regiao.id, id));

  res.json({
    message: "Região atualizada",
  });
});

// DELETE
app.delete("/regiao/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(regiao).where(eq(regiao.id, id));

  res.json({
    message: "Região deletada",
  });
});

/* =======================
   USUARIO CRUD
======================= */

// CREATE
app.post("/usuario", async (req, res) => {
  const {
    id,
    nome,
    email,
    telefone,
    data_nascimento,
  } = req.body;

  await db.insert(usuario).values({
    id,
    nome,
    email,
    telefone,
    data_nascimento,
  });

  res.json({
    message: "Usuário criado",
  });
});

// READ
app.get("/usuario", async (req, res) => {
  const data = await db.select().from(usuario);

  res.json(data);
});

// UPDATE
app.put("/usuario/:id", async (req, res) => {
  const { id } = req.params;

  const {
    nome,
    email,
    telefone,
    data_nascimento,
  } = req.body;

  await db
    .update(usuario)
    .set({
      nome,
      email,
      telefone,
      data_nascimento,
    })
    .where(eq(usuario.id, id));

  res.json({
    message: "Usuário atualizado",
  });
});

// DELETE
app.delete("/usuario/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(usuario).where(eq(usuario.id, id));

  res.json({
    message: "Usuário deletado",
  });
});

// CREATE
app.post("/servico", async (req, res) => {
  const {
    id,
    nome,
    descricao,
    preco
  } = req.body;

  await db.insert(servico).values({
    id,
    nome,
    descricao,
    preco,
  });

  res.json({
    message: "Serviço criado",
  });
});

// READ
app.get("/servico", async (req, res) => {
  const data = await db.select().from(servico);

  res.json(data);
});

// UPDATE
app.put("/servico/:id", async (req, res) => {
  const { id } = req.params;

  const {
    nome,
    descricao,
    preco
  } = req.body;

  await db
    .update(servico)
    .set({
      nome,
      descricao,
      preco,
    })
    .where(eq(servico.id, id));

  res.json({
    message: "Serviço atualizado",
  });
});

// DELETE
app.delete("/servico/:id", async (req, res) => {
  const { id } = req.params;

  await db
    .delete(servico)
    .where(eq(servico.id, id));

  res.json({
    message: "Serviço deletado",
  });
});

// CREATE
app.post("/financeiro", async (req, res) => {
  const {
    id,
    descricao,
    valor,
    tipo,
    data,
    tipo_pagamento,
    status,
    observacao
  } = req.body;

  await db.insert(financeiro).values({
    id,
    descricao,
    valor,
    tipo,
    data,
    tipo_pagamento,
    status,
    observacao,
  });

  res.json({
    message: "Registro financeiro criado",
  });
});

// READ
app.get("/financeiro", async (req, res) => {
  const data = await db
    .select()
    .from(financeiro);

  res.json(data);
});

// UPDATE
app.put("/financeiro/:id", async (req, res) => {
  const { id } = req.params;

  const {
    descricao,
    valor,
    tipo,
    data,
    tipo_pagamento,
    status,
    observacao
  } = req.body;

  await db
    .update(financeiro)
    .set({
      descricao,
      valor,
      tipo,
      data,
      tipo_pagamento,
      status,
      observacao,
    })
    .where(eq(financeiro.id, id));

  res.json({
    message: "Registro atualizado",
  });
});

// DELETE
app.delete("/financeiro/:id", async (req, res) => {
  const { id } = req.params;

  await db
    .delete(financeiro)
    .where(eq(financeiro.id, id));

  res.json({
    message: "Registro deletado",
  });
});



/* =======================
   SERVER
======================= */

app.listen(3000, () => {
  console.log("Servidor rodando em http://localhost:3000");
});