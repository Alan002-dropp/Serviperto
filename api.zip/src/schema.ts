import { sqliteTable, text } from "drizzle-orm/sqlite-core";

export const uf = sqliteTable("uf", {
  id: text("id").primaryKey(),
  nome: text("nome").notNull(),
  sigla: text("sigla").notNull(),
});

export const cidade = sqliteTable("cidade", {
  id: text("id").primaryKey(),
  nome: text("nome").notNull(),
  uf_id: text("uf_id").notNull(),
});

export const regiao = sqliteTable("regiao", {
  id: text("id").primaryKey(),
  nome: text("nome").notNull(),
  cidade_id: text("cidade_id").notNull(),
});

export const usuario = sqliteTable("usuario", {
  id: text("id").primaryKey(),

  nome: text("nome").notNull(),

  email: text("email").notNull(),

  telefone: text("telefone").notNull(),

  data_nascimento: text("data_nascimento").notNull(),
});

export const servico = sqliteTable("servico", {
  id: text("id").primaryKey(),

  nome: text("nome").notNull(),

  descricao: text("descricao").notNull(),

  preco: text("preco").notNull(),
});

export const financeiro = sqliteTable("financeiro", {
  id: text("id").primaryKey(),

  descricao: text("descricao").notNull(),

  valor: text("valor").notNull(),

  tipo: text("tipo").notNull(),

  data: text("data").notNull(),

  tipo_pagamento: text("tipo_pagamento").notNull(),

  status: text("status").notNull(),

  observacao: text("observacao").notNull(),
});